function sendEmail(){
    Email.send({
       SecureToken:"b65ec7ab-7b2a-4aa3-b80c-66a0632dfd5e",
        To:'azeemkaisarkhan@gmail.com',
        from:"mazeemxyz@gmail.com",
        Subject:"Buddy Wants to Connect you Azeem",
        Body:"Nothing",
    }).then(
        message=> alert("Mail Sent");
    );
}